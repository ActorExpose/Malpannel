<?php
	$database_host = 'localhost'; //сервер базы данных
	$database_user = 'root'; // имя пользователя БД
	$database_pass = ''; //пароль пользователя БД
	$database_name = 'zor'; //имя базы данных
	
	$reports_show_count = 15;
?>