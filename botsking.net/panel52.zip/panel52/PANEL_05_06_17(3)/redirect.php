<?php
define('N3N', 1);
include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

if (!CheckGuest()) {
    NotFound();
}

$_redirect_to = htmlspecialchars($_GET['url']);
header('Refresh: 0; url=' . $_redirect_to);
?>
<html>
<head>
    <title>Redirecting...</title>
    <meta name="referrer" content="no-referrer" />
    <meta http-equiv="refresh" content="0;url=<?php echo $_redirect_to; ?>">
</head>
<body>
Attempting to redirect to <a href="<?php echo $_redirect_to; ?>"><?php echo $_redirect_to; ?></a>.
</body>
</html>