<?php
if (!defined('N3N')) {
    include_once __DIR__ . '/../config.php';
}

$_mysqli = new mysqli($db_host, $db_login, base64_decode($db_password), $db_database);
if ($_mysqli->connect_error) {
    die('Connection error - ' . $_mysqli->connect_errno . ' ' . '<br>' . $_mysqli->connect_error);
}

if (array_key_exists('login', $_POST)) {

    $data = $_mysqli->query('SELECT client_id, client_password FROM ' . DB_USERS . ' WHERE client_username = "' . $_mysqli->real_escape_string($_POST['client_username']) . '" LIMIT 1')->fetch_assoc();
    if ($data['client_password'] == md5($_POST['client_password'])) {
        $hash = md5(md5(mt_rand() . microtime()));
        $_mysqli->query('UPDATE ' . DB_USERS . ' SET client_hash= "' . $hash . '" WHERE client_id = "' . $data['client_id'] . '"');
        $_mysqli->close();

        setcookie('client_id', $data['client_id'], time() + (60 * 60 * 24) * 30);
        setcookie('client_hash', $hash, time() + (60 * 60 * 24) * 30);
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();

    } else {
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    }
}

if (array_key_exists('client_id', $_COOKIE) and array_key_exists('client_hash', $_COOKIE)) {

    $sql_query = $_mysqli->query('SELECT * FROM ' . DB_USERS . ' WHERE client_id = "' . $_mysqli->real_escape_string($_COOKIE['client_id']) . '" LIMIT 1')->fetch_array();
    $_mysqli->close();

    if (($sql_query['client_hash'] != $_COOKIE['client_hash']) or ($sql_query['client_id'] != $_COOKIE['client_id'])) {
        setcookie('client_id', '', time() - 1);
        unset($_COOKIE['client_id']);

        setcookie('client_hash', '', time() - 1);
        unset($_COOKIE['client_hash']);
        header('Location: ' . htmlspecialchars($_SERVER['PHP_SELF']));
        exit();
    }
} else {
    session_start();
    if (!array_key_exists('csrf', $_SESSION)) {
        $_SESSION['csrf'] = md5(md5(mt_rand() . microtime()));
    }

    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <head>
        <title></title>
        <link rel='stylesheet' href='./css/bootstrap.min.css'>
        <link rel='stylesheet' href='./css/custom.css'>
        <link rel='stylesheet' href='./css/datepicker.css'>

        <script type='text/javascript' src='./js/jquery-1.12.0.min.js'></script>
        <script type='text/javascript' src='./js/bootstrap.min.js'></script>

        <script type='text/javascript' src='./js/md5.js'></script>
        <script type='text/javascript'>
            function calculate_md5() {
                var plain_pwd = document.authentication.client_password.value;
                document.authentication.client_password.value = hex_md5(plain_pwd);
            }
        </script>
        <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
        <style type='text/css'>
            body {
                font-family: 'Roboto', sans-serif;
            }
        </style>
    </head>
    <body>
    <br>
    <div class="panel panel-primary" style="width: 30%;margin: 0 auto; text-align: center">
        <div class="panel-body">
            <form name="authentication" method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" class="form-control" name="client_username" placeholder="Username">
                </div>
                <p></p>
                <div class="input-group">
                    <span class="input-group-addon"> <i class="glyphicon glyphicon glyphicon-lock"></i></span>
                    <input type="password" class="form-control" name="client_password" autocomplete="off" placeholder="Password">
                </div>
                <p></p>
                <button type="submit" name="login" onclick="calculate_md5()" class="btn btn-primary btn-sm" style="width: 100%">Sign in</button>
                <input name="csrf" type="hidden" value="<?php echo $_SESSION['csrf'] ?>">
            </form>
        </div>
    </div>
    </body>
    <?php
    exit();
}