<?php
define('N3N', 1);
include __DIR__ . '/config.php';
include __DIR__ . '/functions.php';

if (!CheckGuest()) {
    NotFound();
}

$_raw_file = $_GET['file'];
$_file_name = urlencode($_GET['name']);

$_raw_file = str_replace('/', '', $_raw_file);
$_raw_file = str_replace('.', '', $_raw_file);
$_raw_file = './' . DIR_FILES . '/' . str_replace('../', '', $_raw_file);

if (!is_file($_raw_file)) {
    NotFound();
} else {
    header('Content-Type: application/octet-stream');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . filesize($_raw_file));
    header('Content-Disposition: attachment; filename=' . $_file_name);
    readfile($_raw_file);
}