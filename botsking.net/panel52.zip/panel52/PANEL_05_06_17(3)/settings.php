<?php
if(!defined('N3N')) {
    include_once __DIR__ .  '/../config.php';
}
?>

a:5:{s:13:"grabber_plain";s:1:"1";s:14:"grabber_secure";s:1:"0";s:19:"grabber_parse_extra";s:1:"1";s:17:"grabber_blacklist";s:146:"mc.yandex.ru incoming.telemetry.mozilla.org safebrowsing.google.com clients*.google.com ocsp.digicert.com ocsp.comodoca*.com *services.mozilla.com";s:17:"grabber_whitelist";s:27:"*mail*,*google*,*moz*,*pay*";}