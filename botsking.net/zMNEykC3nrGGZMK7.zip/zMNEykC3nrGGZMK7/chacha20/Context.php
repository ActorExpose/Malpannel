<?php

namespace ChaCha20;

class Context
{
    public $state;
    public $buffer = '';
}
