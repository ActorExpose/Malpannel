<?php
require_once('global.php');
session_set_cookie_params(time() + (60 * 30));
session_start();
ob_start();
if (!isset($_SESSION['id']) || $_SESSION['id'] !== md5(LOGIN.PASSWORD_MD5))
{
    header('Location: login.php');
    die();
}
?>