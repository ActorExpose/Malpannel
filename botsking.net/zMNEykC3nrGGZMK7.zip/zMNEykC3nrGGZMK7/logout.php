<?php
    session_set_cookie_params(time() + (60 * 30));
    session_start();
    unset($_SESSION['id']);
    session_write_close();
    header('Location: login.php');
?>