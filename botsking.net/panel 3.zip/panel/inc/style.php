<?php
function css() {
echo '

*{
	margin:0;
	padding:0;
}

body, html {
	font:13px Tahoma,Arial;
}

hr{
	margin:5px;
	border:1px solid black;
}

textarea{
	padding:3px;
	font:11px Tahoma,Arial;
	border:1px solid black;
}

input[type="input"]{
	margin:3px;
	padding:1px;
	border:1px solid black;
}

input[type="submit"]{
	min-width:100px;
	margin:3px;
	padding:1px;
	border:1px solid black;
}

input[type="file"]{
	margin:3px;
	padding:3px;
	border:1px solid black;
}

input[type="radio"],input[type="checkbox"]{
	margin-right:3px;
	vertical-align:middle;
}

select{
	border:1px solid black;
}

.action {
	text-decoration:underline;
	color: #000000;
}

.action:hover {
	color: #e62104;
}

#info th{
	min-width:140px;
	padding:3px;
	text-transform:uppercase;
	background-color:#a7abb0;
}

#info td{
	//border:1px solid #ccc;
	text-transform:uppercase;
	font-size:11px;
	padding:10px;
	vertical-align:top;
}

#info img{
	padding:3px;
	vertical-align:middle;
}

#bots th{
	min-width:80px;
	padding:3px;
	text-transform:uppercase;
	background-color:#a7abb0;
}

#bots tr.blank:hover{
	background-color:#e5e6e8;
}

#bots tr.bottom{
	height:80px;
}

#bots td{
	padding:3px;
	text-transform:uppercase;
	font-size:11px;
	vertical-align:middle;
}

#bots img{
	padding-right:3px;
	vertical-align:middle;
}

#task th{
	//min-width:40px;
	text-transform:uppercase;
	padding:3px;
	background-color:#a7abb0;
}

#task tr.blank:hover{
	background-color:#e5e6e8;
}

#task tr.bottom{
	height:80px;
}

#task td{
	padding:3px;
	text-transform:uppercase;
	font-size:11px;
	vertical-align:middle;
}

#task img{
	padding:3px;
	vertical-align:middle;
}

#main {
	position: relative;
}

#menu{
	float:left;
	background:#fff;
	width:150px;
	border:1px solid #cccccc;
	padding:3px;
	position:relative;
	margin:15px 0 0 15px;
}

#menu ul{
	list-style:none;
}

#menu li{
	list-style:none;
	display:block;
	border-bottom:1px solid #fff;
}

#menu li a{
	list-style:none;
	display:block;
	background:#a7abb0;
	color:#000;
	text-transform:uppercase;
	font-weight:bold;
	font-size:13px;
	text-decoration:none;
	padding:5px 5px 10px 15px;
}

#menu li a:hover{
	background:#fcf5ea;
	color:#000;
	text-decoration:none;
}

#data {
	float:left;
	margin:15px 0 0 15px;
	position:relative;
}

#status {
	padding:3px;
	font:11px Tahoma,Arial;
}

#personal {
	width:500px;
	height:300px;
	padding:20px;
	margin:auto;
	top:0;right:0;bottom:10;left:0;
	position:absolute;
	border:1px solid #ccc;
	background-color: #fff;
}

#secissues {
	width:460px;
	padding:20px;
	margin:auto;
	top:0;right:0;bottom:0;left:0;
	position:absolute;
	border:1px solid #ccc;
	background-color: #fff;
}

';
}
?>