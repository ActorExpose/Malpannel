<?php
// DB details 
$hostname	= 'mysql16.000webhost.com'; // Your Host Name
$database	= 'a6742448_money'; // DataBase Name
$username	= 'a6742448_mad'; // Database Username
$password	= 'solvent123'; // Password

// Acess details
$adminuser = 'admin';
$adminpass = 'solvent123';

// Config
$logsperpage	= 100; // how many logs to show per page?
?>