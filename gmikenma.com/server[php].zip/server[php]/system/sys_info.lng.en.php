<?php if(!defined('__CP__'))die();
define('LNG_SYS', 'Information');

define('LNG_SYS_VERSIONS', 'Software versions');
define('LNG_SYS_PATHS',    'Paths');
define('LNG_SYS_CLIENT',   'Client');
?>