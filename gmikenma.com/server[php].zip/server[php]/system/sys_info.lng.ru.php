<?php if(!defined('__CP__'))die();
define('LNG_SYS', 'Информация');

define('LNG_SYS_VERSIONS', 'Версии ПО');
define('LNG_SYS_PATHS',    'Пути');
define('LNG_SYS_CLIENT',   'Клиент');
?>