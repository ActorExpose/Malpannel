<?php
// DB details 
$hostname	= 'mysql14.000webhost.com'; // Your Host Name
$database	= 'a9084073_ok'; // DataBase Name
$username	= 'a9084073_ok'; // Database Username
$password	= 'Ehimembano1@'; // Password

// Acess details
$adminuser = 'admin';
$adminpass = 'wassodedon';

// Config
$logsperpage	= 100; // how many logs to show per page?
?>